/fs/usb0/navimaps.ino.elf
