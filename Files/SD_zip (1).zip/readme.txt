# Start the unit with a different name-set to the hd0/usb0 device:

SD.ino.elf disk name=sd blk cache=2m,auto=partition,automount=sd0@dos:/fs/sd0,rw dos exe=all
